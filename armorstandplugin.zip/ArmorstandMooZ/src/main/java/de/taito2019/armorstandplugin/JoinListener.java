package de.taito2019.armorstandplugin;

import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListener implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        player.addPassenger(player.getWorld().spawn(player.getLocation(), ArmorStand.class));
                //boolean addPassenger(@NotNull Entity passenger
        //player.getPassengers(ArmorStand)
    }
}

