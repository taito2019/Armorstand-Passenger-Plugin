package de.taito2019.armorstandplugin;

import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.checkerframework.common.returnsreceiver.qual.This;
import org.jetbrains.annotations.NotNull;

public final class Armorstandplugin extends JavaPlugin {

}

    @Override
    public void onEnable() {
        // Plugin startup logic

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }

    PluginManager pluginManager = Bukkit.getPluginManager();


    private void listenerRegistration() {
        pluginManager.registerEvent(new JoinListener(),this);
        }

}